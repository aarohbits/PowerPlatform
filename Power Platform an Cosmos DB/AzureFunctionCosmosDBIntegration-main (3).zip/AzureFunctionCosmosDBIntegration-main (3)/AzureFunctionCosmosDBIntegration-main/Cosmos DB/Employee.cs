using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Cosmos_DB.Model.Request;
using Microsoft.Extensions.Configuration;
using Cosmos_DB.Services;

namespace Cosmos_DB
{
    public class Employee
    {
        private readonly IConfiguration _config;
        private const string COSMOS_ENDPOINT = "COSMOS_ENDPOINT";
        private const string COSMOS_KEY = "COSMOS_KEY";
        private const string DBName = "DBName";

        public Employee(ILogger<Employee> log)
        {

            _config = new ConfigurationBuilder()
                .SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile("local.settings.json", optional: true)
                .AddEnvironmentVariables()
                .Build();
        }

        [FunctionName("Create")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post")] HttpRequest req,
            ILogger log)
        {
            try
            {
                log.LogInformation("C# HTTP trigger function processed a Create request.");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                CreateRequest createRequest = JsonConvert.DeserializeObject<CreateRequest>(requestBody);
                CosmosDBService cosmosDBService = new CosmosDBService(_config[COSMOS_ENDPOINT], _config[COSMOS_KEY], _config[DBName]);
                await cosmosDBService.CreatData(createRequest);
                //return new OkObjectResult("created");
               return new OkObjectResult(new {id = createRequest.id });
            }
            catch (Exception ex)
            {
                return new ObjectResult(ex);
            }
        }

        [FunctionName("Delete")]
        public async Task<IActionResult> Delete(
            [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "Delete/{empId}")] HttpRequest req, string empId,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a Delete request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();           
            CosmosDBService cosmosDBService = new CosmosDBService(_config[COSMOS_ENDPOINT], _config[COSMOS_KEY], _config[DBName]);            
            await cosmosDBService.DeleteData(empId);

            return new OkObjectResult("Deleted");
        }

        [FunctionName("Update")]
        public async Task<IActionResult> Update(
            [HttpTrigger(AuthorizationLevel.Anonymous, "put", Route = "Update/{empId}")] HttpRequest req, string empId,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed an Update request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            CreateRequest updateRequest = JsonConvert.DeserializeObject<CreateRequest>(requestBody);
            CosmosDBService cosmosDBService = new CosmosDBService(_config[COSMOS_ENDPOINT], _config[COSMOS_KEY], _config[DBName]);
            updateRequest.empid = empId;
            await cosmosDBService.UpdateData(updateRequest);
            return new OkObjectResult("Updated");
        }

        [FunctionName("GetAllProjectExpense")]
        public async Task<IActionResult> GetAllProjectExpense(
           [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "GetAllProjectExpense")] HttpRequest req,
           ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a GetAllProjectExpense request.");
            CosmosDBService cosmosDBService = new CosmosDBService(_config[COSMOS_ENDPOINT], _config[COSMOS_KEY], _config[DBName]);            
            var result = await cosmosDBService.GetAllData();
            return new OkObjectResult(result);
        }
    }
}
