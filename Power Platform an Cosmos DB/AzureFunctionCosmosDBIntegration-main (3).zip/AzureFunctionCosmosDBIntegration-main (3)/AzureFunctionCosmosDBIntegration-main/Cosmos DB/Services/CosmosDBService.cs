﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cosmos_DB.Model.Request;
using Cosmos_DB.Models.Response;
using Microsoft.Azure.Cosmos;

namespace Cosmos_DB.Services
{
    internal class CosmosDBService
    {
        private CosmosClient client;
        private readonly string URL;
        private readonly string ConnectionString;
        private readonly string DBName;
        public CosmosDBService(string url, string key, string dbName)
        {
            this.URL = url;
            this.ConnectionString = key;
            this.DBName = dbName;
            
        }

        public async Task<ItemResponse<CreateRequest>> CreatData(CreateRequest employee)
        {
            client = new CosmosClient(URL, ConnectionString);
            await client.CreateDatabaseIfNotExistsAsync(id: DBName);
            Database database = client.GetDatabase(id: DBName);
            Container container = await database.CreateContainerIfNotExistsAsync(
                                                    id: "employeeData",
                                                    partitionKeyPath: "/empid");
           employee.id = Guid.NewGuid().ToString();
           var result =  await  container.CreateItemAsync(
                                                            item: employee,
                                                            partitionKey: new PartitionKey(employee.empid));
            return result;

            //return createdItem != null;
        }

        public async Task<List<ItemResponse<CreateRequest>>> UpdateData(CreateRequest employee)
        {
            client = new CosmosClient(URL, ConnectionString);
            await client.CreateDatabaseIfNotExistsAsync(id: DBName);
            Database database = client.GetDatabase(id: DBName);
            Container container = await database.CreateContainerIfNotExistsAsync(
                                                    id: "employeeData",
                                                    partitionKeyPath: "/empid");
            List<PatchOperation> operations = new List<PatchOperation>();
            if (!string.IsNullOrEmpty(employee.country))
            {
                operations.Add(PatchOperation.Replace("/country", employee.country));
            }
            if (!string.IsNullOrEmpty(employee.description))
            {
                operations.Add(PatchOperation.Replace("/description", employee.description));
            }
            if (!string.IsNullOrEmpty(employee.email))
            {
                operations.Add(PatchOperation.Replace("/email", employee.email));
            }
            if (!string.IsNullOrEmpty(employee.currency))
            {
                operations.Add(PatchOperation.Replace("/currency", employee.currency));
            }
            if (employee.amount != null)
            {
                operations.Add(PatchOperation.Replace("/amount", employee.amount));
            }
            if (!string.IsNullOrEmpty(employee.expensedate))
            {
                operations.Add(PatchOperation.Replace("/expensedate", employee.expensedate));
            }
            List<ItemResponse<CreateRequest>> result = new List<ItemResponse<CreateRequest>>();
            var data = await GetAllData(employee.empid);
            foreach (var d in data)
            {
                try
                {
                    var r = await container.PatchItemAsync<CreateRequest>(
                                                              id: d.Id,
                                                              partitionKey: new PartitionKey(employee.empid),
                                                              patchOperations: operations);
                    result.Add(r);
                }
                catch (Exception ex)
                {

                }
            }
            
            return result;

            //return createdItem != null;
        }
        //public async Task<ItemResponse<CreateRequest>> UpdateData(CreateRequest employee)
        //{
        //    client = new CosmosClient(URL, ConnectionString);
        //    await client.CreateDatabaseIfNotExistsAsync(id: DBName);
        //    Database database = client.GetDatabase(id: DBName);
        //    Container container = await database.CreateContainerIfNotExistsAsync(
        //                                            id: "employeeData",
        //                                            partitionKeyPath: "/empid");            
        //    List<PatchOperation> operations = new List<PatchOperation>();
        //    if(!string.IsNullOrEmpty(employee.country))
        //    {
        //        operations.Add(PatchOperation.Replace("/country", employee.country));
        //    }
        //    if (!string.IsNullOrEmpty(employee.description))
        //    {
        //        operations.Add(PatchOperation.Replace("/description", employee.description));
        //    }
        //    if (!string.IsNullOrEmpty(employee.email))
        //    {
        //        operations.Add(PatchOperation.Replace("/email", employee.email));
        //    }
        //    if (!string.IsNullOrEmpty(employee.currency))
        //    {
        //        operations.Add(PatchOperation.Replace("/currency", employee.currency));
        //    }
        //    if (employee.amount != null)
        //    {
        //        operations.Add(PatchOperation.Replace("/amount", employee.amount));
        //    }
        //    if (!string.IsNullOrEmpty(employee.expensedate))
        //    {
        //        operations.Add(PatchOperation.Replace("/expensedate", employee.expensedate));
        //    }
        //    var result = await container.PatchItemAsync<CreateRequest>(
        //                                                     id: employee.id,
        //                                                     partitionKey: new PartitionKey(employee.empid),
        //                                                     patchOperations: operations);
        //    return result;

        //    //return createdItem != null;
        //}

        //public async Task<ItemResponse<CreateRequest>> DeleteData(string  employeeId, string id)
        //{
        //    client = new CosmosClient(URL, ConnectionString);
        //    await client.CreateDatabaseIfNotExistsAsync(id: DBName);
        //    Database database = client.GetDatabase(id: DBName);
        //    Container container = await database.CreateContainerIfNotExistsAsync(
        //                                            id: "employeeData",
        //                                            partitionKeyPath: "/empid");            
        //    var result = await container.DeleteItemAsync<CreateRequest>(
        //                                                     id: id,
        //                                                     partitionKey: new PartitionKey(employeeId));
        //    return result;

        //    //return createdItem != null;
        //}

        public async Task<List<ItemResponse<CreateRequest>>> DeleteData(string employeeId)
        {
            client = new CosmosClient(URL, ConnectionString);
            await client.CreateDatabaseIfNotExistsAsync(id: DBName);
            Database database = client.GetDatabase(id: DBName);
            Container container = await database.CreateContainerIfNotExistsAsync(
                                                    id: "employeeData",
                                                    partitionKeyPath: "/empid");
            List<ItemResponse<CreateRequest>> result = new List<ItemResponse<CreateRequest>>();
            var data = await GetAllData(employeeId);
            foreach (var d in data)
            {
                try
                {
                    var r = await container.DeleteItemAsync<CreateRequest>(
                                                                     id: d.Id,
                                                                     partitionKey: new PartitionKey(employeeId));
                    result.Add(r);  
                }
                catch(Exception ex)
                {

                }
            }
            return result;

            //return createdItem != null;
        }

        public async Task<List<EmployeeData>> GetAllData(string empId)
        {
            client = new CosmosClient(URL, ConnectionString);
            await client.CreateDatabaseIfNotExistsAsync(id: DBName);
            Database database = client.GetDatabase(id: DBName);
            Container container = await database.CreateContainerIfNotExistsAsync(
                                                    id: "employeeData",
                                                    partitionKeyPath: "/empid");
            List<EmployeeData> employeeDataList = new List<EmployeeData>();
            var query = new QueryDefinition(
    query: "SELECT * FROM employeeData e WHERE e.empid = @empId"
)
    .WithParameter("@empId", empId);

            using FeedIterator<EmployeeData> feed = container.GetItemQueryIterator<EmployeeData>(
                queryDefinition: query
            );

            while (feed.HasMoreResults)
            {
                FeedResponse<EmployeeData> response = await feed.ReadNextAsync();
                foreach (EmployeeData item in response)
                {
                    employeeDataList.Add(item);
                }
            }

            return employeeDataList;
        }
        public async Task<List<EmployeeData>> GetAllData()
        {
            client = new CosmosClient(URL, ConnectionString);
            await client.CreateDatabaseIfNotExistsAsync(id: DBName);
            Database database = client.GetDatabase(id: DBName);
            Container container = await database.CreateContainerIfNotExistsAsync(
                                                    id: "employeeData",
                                                    partitionKeyPath: "/empid");
            List<EmployeeData> employeeDataList = new List<EmployeeData>();
            var query = new QueryDefinition(
    query: "SELECT * FROM employeeData"
);

            using FeedIterator<EmployeeData> feed = container.GetItemQueryIterator<EmployeeData>(
                queryDefinition: query
            );

            while (feed.HasMoreResults)
            {
                FeedResponse<EmployeeData> response = await feed.ReadNextAsync();
                foreach (EmployeeData item in response)
                {
                    employeeDataList.Add(item);
                }
            }
            return employeeDataList;

            //return createdItem != null;
        }

    }
}
