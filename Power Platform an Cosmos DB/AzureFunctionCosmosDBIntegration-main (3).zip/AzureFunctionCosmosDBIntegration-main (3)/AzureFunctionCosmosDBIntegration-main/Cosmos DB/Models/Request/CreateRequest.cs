﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cosmos_DB.Model.Request
{
    // CreateRequest myDeserializedClass = JsonConvert.DeserializeObject<CreateRequest>(myJsonResponse);
    internal class CreateRequest
    {
        public string id { get; set; }  

        //[JsonProperty("empid")]
        public string empid;

        //[JsonProperty("email")]
        public string email;

        //[JsonProperty("expensedate")]
        public string expensedate;

        //[JsonProperty("description")]
        public string description;

        //[JsonProperty("amount")]
        public int? amount;

        //[JsonProperty("currency")]
        public string currency;

        //[JsonProperty("country")]
        public string country;
    }

    internal class CreateRequest_2
    {
        //[JsonProperty("empid")]
        public string empid;

        //[JsonProperty("email")]
        public string email;

        //[JsonProperty("expensedate")]
        public string expensedate;

        //[JsonProperty("description")]
        public string description;

        //[JsonProperty("amount")]
        public int? amount;

        //[JsonProperty("currency")]
        public string currency;

        //[JsonProperty("country")]
        public string country;
    }
}
