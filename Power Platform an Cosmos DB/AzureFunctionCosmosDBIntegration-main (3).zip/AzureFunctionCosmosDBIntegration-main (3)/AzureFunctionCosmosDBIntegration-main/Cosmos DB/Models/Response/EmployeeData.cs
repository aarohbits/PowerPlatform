﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cosmos_DB.Models.Response
{
    internal class EmployeeData
    {
        public string Empid { get; set; }
        public string Email { get; set; }
        public string Expensedate { get; set; }
        public string Description { get; set; }
        public int Amount { get; set; }
        public string Currency { get; set; }
        public string Country { get; set; }
        public string Id { get; set; }
    }
}
